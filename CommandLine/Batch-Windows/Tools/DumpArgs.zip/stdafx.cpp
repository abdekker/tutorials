// stdafx.cpp : source file that includes just the standard includes
//
// Copyright 2013 WindowsInspired.com
// http://www.windowsinspired.com
//
// You may freely use the content of this file for any non-commercial purpose.
//
// DumpArgs.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
